## How to contribute to BeamBending

First and foremost, thanks for even reading the rules for contributing :+1:

* Pull requests that add features and/or correct bugs are welcome. If you are sending one, please make sure your code passes all the pre-existing tests
* Constructive feedback is always appreciated. If you find a bug or have a feature suggestion, please open an issue or just drop me a line at alfcar@oslomet.no 

